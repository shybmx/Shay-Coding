package javagame;

import city.cs.engine.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import fsm.FSM;
/**
 * creating the enemy Goomba 
 * parameters hold fixtures and images
 * sound to play for Goomba
 * @author shahzad
 */
public class Goomba extends Walker implements StepListener{
    private static SoundClip goomba;   
    public static final float range = 5;
    private FSM<Goomba> fsm;
    private Level1 level1;
    private static final BodyImage goombai = new BodyImage ("data/Goomba1.png", 3.0f);
    private static final Shape goombahead = new PolygonShape(-0.13f,1.09f, -0.91f,0.31f, 
                    -0.91f,-0.05f, -0.64f,-0.31f, 0.89f,-0.32f, 1.14f,-0.06f, 
                    1.14f,0.32f, 0.36f,1.09f);
    private static final Shape goombaBottom = new PolygonShape(-0.64f,-0.31f, -0.92f,-0.59f,
                    -0.92f,-0.83f, 0.37f,-0.95f, 1.13f,-0.96f, 1.14f,-0.72f, 0.88f,-0.31f);
    
    static {
        try {
           goomba = new SoundClip("data/goomba.mp3");
         } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
           System.out.println(e);
         }        
    }
    /**
     * Adding Goomba to level1
     * Make Goomba stand still
     * add the fixtures and image
     * @param level1 
     */
    public Goomba(Level1 level1){
            super(level1, goombahead);
            this.level1 = level1;
            fsm = new FSM<Goomba>(this, new StandStillState());
            level1.addStepListener(this);
            Fixture headFixture = new SolidFixture(this, goombahead);
            Fixture bottomFixture = new SolidFixture(this, goombaBottom);
            addImage(goombai); 
        }
    /**
     * Make the Goomba Run Away from the Man if on the left hand side
     * @return 
     */
    public boolean inRangeLeft(){
        Body a = level1.getMan();
        float gap = getPosition().x - a.getPosition().x;
        return gap < range && gap > 0;
    }
    /** 
     * make the Goomba Run Away from the Man if on the right hand side
     * @return 
     */
    public boolean inRangeRight() {
        Body a = level1.getMan();
        float gap = getPosition().x - a.getPosition().x;
        return gap > -range && gap < 0;
    }
    /**
     * if they are in range of both the left and right side radius
     * @return 
     */
    public boolean inRange() {
        return inRangeLeft() || inRangeRight();
    }
    /**
     * play sound when destroyed
     */
    @Override
    public void destroy(){
    goomba.play();
    super.destroy();
    }
    /**
     * update the FSM 
     * @param e 
     */
    public void preStep(StepEvent e) {
        fsm.update();
    }

    @Override
    public void postStep(StepEvent e) {}
}