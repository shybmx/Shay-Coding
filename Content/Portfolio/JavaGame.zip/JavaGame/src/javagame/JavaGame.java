package javagame;

import city.cs.engine.*;
import java.awt.*;
import javax.swing.*;
import org.jbox2d.common.Vec2;
/**
 * Where everything will be created
 * The main Game
 * @author shahzad
 */
public class JavaGame {

   private GameLevel world; 
   private UserView view;
   public final JFrame frame;
   public int level;
   private Control control;
   private ControlPanel panel;
   private Man man;
   
   /**
    * adding the frame
    * adding controls
    * adding control panel GUI
    * adding text on bottom of screen
    * adding camera to follow player
    * Has debugger
    * Gird for building
    * Starts on Level 1
    * Starts the world
    */
   public JavaGame() {
      world = new Level1();
      level = 1;
      world.populate(this);
      Safe safe = world.getSafe();
      Man man = world.getMan();
           
      //build the level Horizontally 
      //view = new UserView(world, 1600, 1000);

      //Vertical levels
      //view = new UserView(world, 1000, 1600);
      
      Goomba goomba = new Goomba((Level1) world);
      goomba.setPosition(new Vec2(0, -16));
      goomba.addCollisionListener(new GoombaCollision(getMan()));
     
       //the acutal game
       view = new MyView(world, 600, 600); 
       view = new CoinView(world, man, 600, 600);
         
       //creating the frame for the game to be played in 
       frame = new JFrame("Carry The Box!");
       frame.add(new ControlPanel(this), BorderLayout.NORTH);
       frame.repaint(60);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setLocationByPlatform(true);
       frame.add(view, BorderLayout.CENTER);
       frame.setResizable(false);
       frame.pack();
       frame.setVisible(true);
       frame.requestFocus();
       JLabel text = new JLabel();
       text.setText("Shahzad Emambaccus Milestone 3 ACJW729");
       frame.add(text, BorderLayout.SOUTH);
      
       //controlling the main character 
       control = new Control (world.getMan());
       frame.addKeyListener(control);
       
       //making the camera follow the character 
       world.addStepListener(new Camera(view, world.getMan()));
       
      //JFrame debugView = new DebugViewer(world, 1000, 1000);
      //view.setGridResolution(1);
        
       world.start();
   }
    /**
     * when Man Touches Gate This will move onto the next level
     * At the End Shows end game panel
     */
    public void nextLevel(){
       world.stop();
       level++;
       System.out.println("Level Up");
       if (level == 5){
           new EndGame();
       }else if(level == 2){
            world = new Level2();
            //JFrame debugView = new DebugViewer(world, 1000, 1000);
            world.populate(this);
            control = new Control(world.getMan());
            control.setbody(world.getMan());
            frame.addKeyListener(control);
            view.setWorld(world);
            frame.requestFocus();
            world.addStepListener(new Camera(view, world.getMan()));
            world.start();
        }else if(level == 3){
            world = new Level3();
            //JFrame debugView = new DebugViewer(world, 1000, 1000);
            world.populate(this);
            control = new Control(world.getMan());
            control.setbody(world.getMan());
            frame.addKeyListener(control);
            view.setWorld(world);
            frame.requestFocus();
            world.addStepListener(new Camera(view, world.getMan()));
            world.start();
        }else if(level == 4){
            world = new Level4();
            //JFrame debugView = new DebugViewer(world, 1000, 1000);
            world.populate(this);
            control = new Control(world.getMan());
            control.setbody(world.getMan());
            frame.addKeyListener(control);
            view.setWorld(world);
            frame.requestFocus();
            world.addStepListener(new Camera(view, world.getMan()));
            world.start(); 
        }
    }
    /**
     * if Man collects x coins goes to bonus level 
     */
    public void bounsLevel(){
        world.stop();
        world = new BounsLevel();
        //JFrame debugView = new DebugViewer(world, 1000, 1000);
        world.populate(this);
        control = new Control(world.getMan());
        control.setbody(world.getMan());
        frame.addKeyListener(control);
        view.setWorld(world);
        frame.requestFocus();
        world.addStepListener(new Camera(view, world.getMan()));
        world.start(); 
    }
    /** 
     * return Man
     * @return 
     */
   public Man getMan(){
       return world.getMan();
   }
   /**
    * return the position for safe/box
    * @return 
    */
   public Safe getSafe(){
       return world.getSafe();
   }
   /**
    * return world
    * @return 
    */
   public GameLevel getWorld(){
       return world;
   }
   /**
    * return the gold count
    * @return 
    */
   public int getCoin(){
        return man.goldcoinCount();
   }
}