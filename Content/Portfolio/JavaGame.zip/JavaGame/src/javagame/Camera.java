package javagame;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
/**
 * Setting Camera to follow player
 * @author shahzad
 */
public class Camera implements StepListener{
    private WorldView view;
    private Body body;
    
    /**
     * Setting Parameter
     * @param view
     * @param body 
     */
public Camera(WorldView view, Body body){
        this.view = view;
        this.body = body;
}
   @Override
    public void preStep(StepEvent e){
    }
    
    /**
     * Making the camera follow the camera in main game
     * @param e 
     */
    @Override
    public void postStep(StepEvent e){
        view.setCentre(new Vec2(body.getPosition()));
        }
}
