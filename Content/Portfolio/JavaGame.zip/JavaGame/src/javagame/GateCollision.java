package javagame;

import city.cs.engine.*;
/**
 * gate collision when man touches it
 * @author shahzad
 */
public class GateCollision implements CollisionListener {
    private JavaGame javagame;
    /**
     * what will be changed when collision occurs
     * @param javagame 
     */
    public GateCollision(JavaGame javagame){
        this.javagame = javagame;
    }
    /**
     * if man touches gate with x coins moves onto bonus level
     * if else they will move onto second level
     * @param e 
     */
    @Override
    public void collide(CollisionEvent e) {
        Man man = javagame.getMan();
        if(e.getOtherBody() == javagame.getMan() && man.goldcoinCount() == 37){
            javagame.bounsLevel();
        } else if (e.getOtherBody() == javagame.getMan()){
            javagame.nextLevel();
        } 
    }
}