package javagame;

import fsm.FSMState;
/**
 * Make Gordo walk Right
 * @author shahzad
 */
public class GordoWalkRight extends FSMState<GordoSpikes> {
    /**
     * if Man is on the left hand side walk right
     */
    protected void update() {
        GordoSpikes gordo = getContext();
        if (gordo.inRangeLeft()) {
            gotoState(new GordoWalkLeft());
        } else if (!gordo.inRange()) {
            gotoState(new GordoStandStill());
        } else {
            gordo.startWalking(2);
        }
    }
    /**
     * get Context
     */
    protected void enter() {
        GordoSpikes gordo = getContext();
    }

    protected void exit() {
    }   
}