package javagame;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
/**
 * creating level 3
 * @author shahzad
 */
public class Level3 extends GameLevel{
    /**
     * populating level 3
     * @param javagame 
     */
   @Override
    public void populate(JavaGame javagame) {
        super.populate(javagame);
        Shape floor = new BoxShape(37.5f, 4.5f);
        Shape wall = new BoxShape(0.5f, 27.5f);
        Shape step = new BoxShape(2, 0.5f);
        Shape box = new BoxShape(0.5f, 0.5f);
        
        Body platform = new StaticBody(this, floor);
        platform.addImage(new BodyImage("data/floor.png", 9.1f));
        platform.setPosition(new Vec2(0,-23));
        
        Body platform1 = new StaticBody(this, wall);
        platform1.addImage(new BodyImage("data/wall.png", 35), new Vec2(0, -1));
        platform1.setPosition(new Vec2(-37.5f, 0));

        Body platform2 = new StaticBody(this, wall);
        platform2.addImage(new BodyImage("data/wall.png", 35), new Vec2(0, -1));
        platform2.setPosition(new Vec2(37.5f, 0));
        
        Body platform3 = new StaticBody(this, box);
        platform3.addImage(new BodyImage("data/box.png", 1.3f));
        platform3.setPosition(new Vec2(-25, 10));
        
        Body platform4 = new StaticBody(this, box);
        platform4.addImage(new BodyImage("data/box.png", 1.3f));
        platform4.setPosition(new Vec2(-15, -17));
        
        Body platform5 = new StaticBody(this, box);
        platform5.addImage(new BodyImage("data/box.png", 1.3f));
        platform5.setPosition(new Vec2(-10, -17));
        
        Body platform6 = new StaticBody(this, box);
        platform6.addImage(new BodyImage("data/box.png", 1.3f));
        platform6.setPosition(new Vec2(-5, -17));
        
        Body platform7 = new StaticBody(this, box);
        platform7.addImage(new BodyImage("data/box.png", 1.3f));
        platform7.setPosition(new Vec2(0, 10));
        
        Body platform8 = new StaticBody(this, box);
        platform8.addImage(new BodyImage("data/box.png", 1.3f));
        platform8.setPosition(new Vec2(5, -10));
        
        Safe safe = new Safe(this);
        safe.setPosition(new Vec2(10, -5));
        
        Safe safe1 = new Safe(this);
        safe1.setPosition(new Vec2(20, -15));
        
        Safe safe2 = new Safe(this);
        safe2.setPosition(new Vec2(10, -15));
        
        Safe safe3 = new Safe(this);
        safe3.setPosition(new Vec2(2, -15));
        
        Safe safe4 = new Safe(this);
        safe4.setPosition(new Vec2(21, 0));
        
        Spikes spikes3 = new Spikes(this);
        spikes3.setPosition(new Vec2(10, -10));
        spikes3.addCollisionListener(new SpikesCollision(getMan()));
        
        Spikes spikes4 = new Spikes(this);
        spikes4.setPosition(new Vec2(25, -7.5f));
        spikes4.addCollisionListener(new SpikesCollision(getMan()));
        
        Goldcoin coin = new Goldcoin(this);
        coin.setPosition(new Vec2(-27, -17));
        coin.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin1 = new Goldcoin(this);
        coin1.setPosition(new Vec2(-27, -13));
        coin1.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin2 = new Goldcoin(this);
        coin2.setPosition(new Vec2(-35, -8));
        coin2.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin3 = new Goldcoin(this);
        coin3.setPosition(new Vec2(-27, -3));
        coin3.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin4 = new Goldcoin(this);
        coin4.setPosition(new Vec2(-35, 2));
        coin4.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin5 = new Goldcoin(this);
        coin5.setPosition(new Vec2(-27, 7));
        coin5.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin6 = new Goldcoin(this);
        coin6.setPosition(new Vec2(-35, 12));
        coin6.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin7 = new Goldcoin(this);
        coin7.setPosition(new Vec2(-25, 12));
        coin7.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin8 = new Goldcoin(this);
        coin8.setPosition(new Vec2(-15, -15));
        coin8.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin9 = new Goldcoin(this);
        coin9.setPosition(new Vec2(-23, -13));
        coin9.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin10 = new Goldcoin(this);
        coin10.setPosition(new Vec2(2, -13));
        coin10.addCollisionListener(new CollectCoin(getMan()));
        
        float i = -15;
        while (i < 15) {
            Spikes spikes = new Spikes(this);
            spikes.setPosition(new Vec2(-25 , i));
            spikes.setAngleDegrees(90);
            spikes.addCollisionListener(new SpikesCollision(getMan()));
            i = i + 10;
        }
        
        float x = -15;
        while (x < 15){
            Body platforms = new StaticBody(this, step);
            platforms.addImage(new BodyImage("data/step1.png", 1.1f));
            platforms.setPosition(new Vec2(-27, x));
            x = x + 10;
        }
        
        float y = - 10;
        while (y < 15){
            Body platforms1 = new StaticBody(this, step);
            platforms1.addImage(new BodyImage("data/step1.png", 1.1f));
            platforms1.setPosition(new Vec2(-35, y));
            y = y + 10;
        }
        
        float z = -20;
        while (z < 40){
            Spikes spikes1 = new Spikes(this);
            spikes1.setPosition(new Vec2(z, -18));
            spikes1.addCollisionListener(new SpikesCollision(getMan()));
            z = z + 10;
        }
        
        float a = -5;
        while (a < 15) {
            Spikes spikes2 = new Spikes(this);
            spikes2.setPosition(new Vec2(-10 , a));
            spikes2.setAngleDegrees(90);
            spikes2.addCollisionListener(new SpikesCollision(getMan()));
            a = a + 10;
        }
        
        float b = -15;
        while (b < 15) {
            Spikes spikes = new Spikes(this);
            spikes.setPosition(new Vec2(0 , b));
            spikes.setAngleDegrees(90);
            spikes.addCollisionListener(new SpikesCollision(getMan()));
            b = b + 10;
        }
        
        float c = -15;
        while (c < 15){
            Body platforms2 = new StaticBody(this, step);
            platforms2.addImage(new BodyImage("data/step1.png", 1.1f));
            platforms2.setPosition(new Vec2(-1.5f, c));
            c = c + 10;
        }
        
        float d = - 10;
        while (d < 15){
            Body platforms3 = new StaticBody(this, step);
            platforms3.addImage(new BodyImage("data/step1.png", 1.1f));
            platforms3.setPosition(new Vec2(-8.5f, d));
            d = d + 10;
        }   
    }
    /**
     * set starting position for man in this level
     * @return 
     */
    @Override
    public Vec2 startPosition() {
         return new Vec2(-35, -17);
    }
    /**
     * set gate position in this level
     * @return 
     */
    @Override
    public Vec2 gatePosition() {
   return new Vec2(25, 0);
    }   
}