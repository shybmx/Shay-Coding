package javagame;

import city.cs.engine.*;
/**
 * Collision for the spikes
 * @author shahzad
 */
public class SpikesCollision implements CollisionListener {
    private Man man;
    /**
     * setting the man variable
     * @param man 
     */
    public SpikesCollision(Man man){
        this.man = man;
    }
    /**
     * if man touchs the spikes 
     * set life to 0
     * @param e 
     */
    public void collide(CollisionEvent e){
        if(e.getOtherBody() == man){
           man.dead();
           e.getOtherBody().destroy();
        }   
    }
}