package javagame;

import city.cs.engine.*;
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
/**
 * adding background
 * @author shahzad
 */
public class MyView extends UserView {
    private final Image background;
    /**
     * the sizes and the file
     * @param world
     * @param width
     * @param height 
     */
    public MyView(World world, int width, int height) {
        super(world, width, height);
        background = new ImageIcon("data/game-background.jpg").getImage();
    }
    /**
     * drawing the background
     * @param g 
     */ 
    @Override
    protected void paintBackground(Graphics2D g) {
       g.drawImage(background, 0, 0, this);
    }
}