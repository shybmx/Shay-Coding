package javagame;
/**
 * creating screen for the end of the game
 * @author shahzad
 */
public class EndGame extends javax.swing.JFrame {
    private JavaGame game;
   /**
    * when game ends this screen will appear
    * setting size
    * visible
    */
    public EndGame() {
        initComponents();
        this.setSize(764, 716);
        this.setResizable(false);
        this.setLocationByPlatform(true);
        this.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        backToMenu = new javax.swing.JButton();
        soundTrack = new javax.swing.JButton();
        replay = new javax.swing.JButton();
        exitGame = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        backToMenu.setText("Back To Menu");
        backToMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToMenuActionPerformed(evt);
            }
        });
        getContentPane().add(backToMenu);
        backToMenu.setBounds(90, 410, 110, 28);

        soundTrack.setText("Sound Track");
        soundTrack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                soundTrackActionPerformed(evt);
            }
        });
        getContentPane().add(soundTrack);
        soundTrack.setBounds(90, 440, 110, 28);

        replay.setText("RePlay");
        replay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                replayActionPerformed(evt);
            }
        });
        getContentPane().add(replay);
        replay.setBounds(90, 470, 110, 28);

        exitGame.setText("Exit Game");
        exitGame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitGameActionPerformed(evt);
            }
        });
        getContentPane().add(exitGame);
        exitGame.setBounds(90, 500, 110, 28);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\shahzad\\Documents\\City univeristy\\Year 1\\Java Lab\\CourseWork\\JavaGame\\data\\EndGame.png")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 770, 710);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * goes back to the start menu
     * @param evt 
     */
    private void backToMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToMenuActionPerformed
        new StartMenu();
    }//GEN-LAST:event_backToMenuActionPerformed
    /**
     * opens up the sound track
     */
    private void soundTrackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_soundTrackActionPerformed
        new SoundTrack();
    }//GEN-LAST:event_soundTrackActionPerformed
    /**
     * restart the whole game
     * @param evt 
     */
    private void replayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_replayActionPerformed
        new JavaGame();
    }//GEN-LAST:event_replayActionPerformed
    /**
     * exits everything
     * @param evt 
     */
    private void exitGameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitGameActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitGameActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backToMenu;
    private javax.swing.JButton exitGame;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton replay;
    private javax.swing.JButton soundTrack;
    // End of variables declaration//GEN-END:variables
}
