package javagame;

import city.cs.engine.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
/**
 * Creating the Health item
 * sound for pickup
 * @author shahzad
 */
public class Health extends Walker{
   private static SoundClip health;
    static {
        try {
           health = new SoundClip("data/Health.mp3");
         } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
           System.out.println(e);
         }        
    }
    /**
     * creating fixture and adding image
     * @param world 
     */
    public Health(World world) {
        super(world);
        Shape health = new PolygonShape(1.51f,1.51f, -1.5f,1.5f, 
                -1.5f,-1.5f, 1.5f,-1.5f);
        Fixture healthFixture = new SolidFixture(this, health);
        addImage (new BodyImage("data/Health.png", 3.0f));
    }      
    /**
     * Play sound when destoryed
     */
    @Override
    public void destroy(){
    health.play();
    super.destroy();
    }
}