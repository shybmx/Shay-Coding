package javagame;

import city.cs.engine.SoundClip;
import java.io.IOException;
import java.util.*;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
/**
 * Creating sound track
 * @author shahzad
 */
public class SoundTrack extends javax.swing.JFrame {
    private ArrayList<String> tracks;
    private SoundClip music;
    /**
     * creating array list for all music
     * set the size for the frame
     * plays the first music
     */
    public SoundTrack() {
        initComponents();
        this.setSize(1129, 702);
        this.setResizable(false);
        this.setLocationByPlatform(true);
        this.setVisible(true);
       
        
        tracks = new ArrayList<String>();
        tracks.add("data/Level1.mp3");
        tracks.add("data/Level2.mp3");
        tracks.add("data/Level3.mp3");
        tracks.add("data/Level4.mp3");
        tracks.add("data/Level5.mp3");
        tracks.add("data/Level6.mp3");
        tracks.add("data/Level7.mp3");
        tracks.add("data/Level8.mp3");
        tracks.add("data/Level9.mp3");
        tracks.add("data/Level10.mp3");
        tracks.add("data/Level11.mp3");
        tracks.add("data/Level12.mp3");
        tracks.add("data/Level13.mp3");
        tracks.add("data/Level14.mp3");
        tracks.add("data/Level15.mp3");
        tracks.add("data/Level16.mp3");
        tracks.add("data/Level17.mp3");
        tracks.add("data/Level18.mp3");
        tracks.add("data/Level19.mp3");
        tracks.add("data/Level20.mp3");
        
        try{
          music = new SoundClip(tracks.get(0));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        play1 = new javax.swing.JButton();
        play2 = new javax.swing.JButton();
        play3 = new javax.swing.JButton();
        play4 = new javax.swing.JButton();
        play5 = new javax.swing.JButton();
        play6 = new javax.swing.JButton();
        play7 = new javax.swing.JButton();
        play8 = new javax.swing.JButton();
        play9 = new javax.swing.JButton();
        play10 = new javax.swing.JButton();
        play11 = new javax.swing.JButton();
        play12 = new javax.swing.JButton();
        play13 = new javax.swing.JButton();
        play14 = new javax.swing.JButton();
        play15 = new javax.swing.JButton();
        play16 = new javax.swing.JButton();
        play17 = new javax.swing.JButton();
        play18 = new javax.swing.JButton();
        play19 = new javax.swing.JButton();
        play20 = new javax.swing.JButton();
        backToMenu = new javax.swing.JButton();
        volumeUp = new javax.swing.JButton();
        pause = new javax.swing.JButton();
        play = new javax.swing.JButton();
        volumeDown = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        play1.setText("►");
        play1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play1ActionPerformed(evt);
            }
        });
        getContentPane().add(play1);
        play1.setBounds(600, 30, 40, 28);

        play2.setText("►");
        play2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play2ActionPerformed(evt);
            }
        });
        getContentPane().add(play2);
        play2.setBounds(600, 60, 40, 28);

        play3.setText("►");
        play3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play3ActionPerformed(evt);
            }
        });
        getContentPane().add(play3);
        play3.setBounds(600, 90, 40, 28);

        play4.setText("►");
        play4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play4ActionPerformed(evt);
            }
        });
        getContentPane().add(play4);
        play4.setBounds(930, 120, 40, 28);

        play5.setText("►");
        play5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play5ActionPerformed(evt);
            }
        });
        getContentPane().add(play5);
        play5.setBounds(810, 150, 40, 28);

        play6.setText("►");
        play6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play6ActionPerformed(evt);
            }
        });
        getContentPane().add(play6);
        play6.setBounds(810, 180, 40, 28);

        play7.setText("►");
        play7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play7ActionPerformed(evt);
            }
        });
        getContentPane().add(play7);
        play7.setBounds(810, 210, 40, 28);

        play8.setText("►");
        play8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play8ActionPerformed(evt);
            }
        });
        getContentPane().add(play8);
        play8.setBounds(810, 240, 40, 28);

        play9.setText("►");
        play9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play9ActionPerformed(evt);
            }
        });
        getContentPane().add(play9);
        play9.setBounds(810, 280, 40, 28);

        play10.setText("►");
        play10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play10ActionPerformed(evt);
            }
        });
        getContentPane().add(play10);
        play10.setBounds(810, 310, 40, 28);

        play11.setText("►");
        play11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play11ActionPerformed(evt);
            }
        });
        getContentPane().add(play11);
        play11.setBounds(810, 340, 40, 28);

        play12.setText("►");
        play12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play12ActionPerformed(evt);
            }
        });
        getContentPane().add(play12);
        play12.setBounds(810, 370, 40, 28);

        play13.setText("►");
        play13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play13ActionPerformed(evt);
            }
        });
        getContentPane().add(play13);
        play13.setBounds(810, 400, 40, 28);

        play14.setText("►");
        play14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play14ActionPerformed(evt);
            }
        });
        getContentPane().add(play14);
        play14.setBounds(810, 430, 40, 28);

        play15.setText("►");
        play15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play15ActionPerformed(evt);
            }
        });
        getContentPane().add(play15);
        play15.setBounds(810, 470, 40, 28);

        play16.setText("►");
        play16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play16ActionPerformed(evt);
            }
        });
        getContentPane().add(play16);
        play16.setBounds(810, 500, 40, 28);

        play17.setText("►");
        play17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play17ActionPerformed(evt);
            }
        });
        getContentPane().add(play17);
        play17.setBounds(810, 530, 40, 28);

        play18.setText("►");
        play18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play18ActionPerformed(evt);
            }
        });
        getContentPane().add(play18);
        play18.setBounds(810, 560, 40, 28);

        play19.setText("►");
        play19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play19ActionPerformed(evt);
            }
        });
        getContentPane().add(play19);
        play19.setBounds(810, 590, 40, 28);

        play20.setText("►");
        play20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                play20ActionPerformed(evt);
            }
        });
        getContentPane().add(play20);
        play20.setBounds(810, 620, 40, 28);

        backToMenu.setText("Back To Menu");
        backToMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToMenuActionPerformed(evt);
            }
        });
        getContentPane().add(backToMenu);
        backToMenu.setBounds(960, 310, 110, 28);

        volumeUp.setText("Volume ↑");
        volumeUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volumeUpActionPerformed(evt);
            }
        });
        getContentPane().add(volumeUp);
        volumeUp.setBounds(960, 280, 110, 28);

        pause.setText("Pause");
        pause.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pauseActionPerformed(evt);
            }
        });
        getContentPane().add(pause);
        pause.setBounds(960, 340, 110, 28);

        play.setText("Play");
        play.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playActionPerformed(evt);
            }
        });
        getContentPane().add(play);
        play.setBounds(960, 370, 110, 28);

        volumeDown.setText("Volume ↓ ");
        volumeDown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volumeDownActionPerformed(evt);
            }
        });
        getContentPane().add(volumeDown);
        volumeDown.setBounds(960, 400, 110, 28);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\shahzad\\Documents\\City univeristy\\Year 1\\Java Lab\\CourseWork\\JavaGame\\data\\SoundTrack.png")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1130, 710);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * plays the 1st track
     * @param evt 
     */
    private void play1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play1ActionPerformed
       music.stop();
       try{
          music = new SoundClip(tracks.get(0));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
       music.play();
    }//GEN-LAST:event_play1ActionPerformed
    /**
     * plays the 2nd track
     * @param evt 
     */
    private void play2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play2ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(1));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play2ActionPerformed
/**
     * plays the 3rd track
     * @param evt 
     */
    private void play3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play3ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(2));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play3ActionPerformed
/**
     * plays the 4th track
     * @param evt 
     */
    private void play4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play4ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(3));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play4ActionPerformed
    /**
     * plays the 5th track
     * @param evt 
     */
    private void play5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play5ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(4));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play5ActionPerformed
    /**
     * plays the 6th track
     * @param evt 
     */
    private void play6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play6ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(5));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play6ActionPerformed
    /**
     * plays the 7th track
     * @param evt 
     */
    private void play7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play7ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(6));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play7ActionPerformed
    /**
     * plays the 8th track
     * @param evt 
     */
    private void play8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play8ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(7));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play8ActionPerformed
    /**
     * plays the 9th track
     * @param evt 
     */
    private void play9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play9ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(8));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play9ActionPerformed
    /**
     * plays the 10th track
     * @param evt 
     */
    private void play10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play10ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(9));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play10ActionPerformed
    /**
     * plays the 11th track
     * @param evt 
     */
    private void play11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play11ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(10));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play11ActionPerformed
    /**
     * plays the 12th track
     * @param evt 
     */
    private void play12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play12ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(11));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play12ActionPerformed
    /**
     * plays the 13th track
     * @param evt 
     */
    private void play13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play13ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(12));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play13ActionPerformed
    /**
     * plays the 14th track
     * @param evt 
     */
    private void play14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play14ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(13));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play14ActionPerformed
    /**
     * plays the 15th track
     * @param evt 
     */
    private void play15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play15ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(14));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play15ActionPerformed
    /**
     * plays the 16th track
     * @param evt 
     */
    private void play16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play16ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(15));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play16ActionPerformed
    /**
     * plays the 17th track
     * @param evt 
     */
    private void play17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play17ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(16));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play17ActionPerformed
    /**
     * plays the 18th track
     * @param evt 
     */
    private void play18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play18ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(17));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play18ActionPerformed
    /**
     * plays the 19th track
     * @param evt 
     */
    private void play19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play19ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(18));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play19ActionPerformed
    /**
     * plays the 20th track
     * @param evt 
     */
    private void play20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_play20ActionPerformed
        music.stop();
        try{
          music = new SoundClip(tracks.get(19));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
        music.play();
    }//GEN-LAST:event_play20ActionPerformed
    /**
     * go back to menu
     * @param evt 
     */
    private void backToMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToMenuActionPerformed
        this.dispose();
    }//GEN-LAST:event_backToMenuActionPerformed
    /**
     * Increase Volume
     * @param evt 
     */
    private void volumeUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volumeUpActionPerformed
        music.setVolume(2.0);
    }//GEN-LAST:event_volumeUpActionPerformed
    /**
     * Pause the song
     * @param evt 
     */
    private void pauseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pauseActionPerformed
        music.pause();
    }//GEN-LAST:event_pauseActionPerformed
    /**
     * resume the song
     * @param evt 
     */
    private void playActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playActionPerformed
        music.resume();
    }//GEN-LAST:event_playActionPerformed
    /**
     * decrease the volume
     * @param evt 
     */
    private void volumeDownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volumeDownActionPerformed
        music.setVolume(-2.0);
    }//GEN-LAST:event_volumeDownActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backToMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton pause;
    private javax.swing.JButton play;
    private javax.swing.JButton play1;
    private javax.swing.JButton play10;
    private javax.swing.JButton play11;
    private javax.swing.JButton play12;
    private javax.swing.JButton play13;
    private javax.swing.JButton play14;
    private javax.swing.JButton play15;
    private javax.swing.JButton play16;
    private javax.swing.JButton play17;
    private javax.swing.JButton play18;
    private javax.swing.JButton play19;
    private javax.swing.JButton play2;
    private javax.swing.JButton play20;
    private javax.swing.JButton play3;
    private javax.swing.JButton play4;
    private javax.swing.JButton play5;
    private javax.swing.JButton play6;
    private javax.swing.JButton play7;
    private javax.swing.JButton play8;
    private javax.swing.JButton play9;
    private javax.swing.JButton volumeDown;
    private javax.swing.JButton volumeUp;
    // End of variables declaration//GEN-END:variables
}