package javagame;

import city.cs.engine.*;
/**
 * creating the box/Safe
 * @author shahzad
 */
public class Safe extends DynamicBody {
    /**
     * Giving the safe fixture
     * adding the image
     * @param w 
     */
    public Safe(World w) {
        super(w);
        Shape safeShape = new PolygonShape( 1.24f,1.24f, 1.24f,-1.25f, 
                -1.24f,-1.25f, -1.24f,1.24f);
        Fixture fixture = new SolidFixture(this, safeShape);
        addImage(new BodyImage("data/Block.png", 3.0f));
    }
}