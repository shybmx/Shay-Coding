package javagame;

import city.cs.engine.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
/**
 * creating the coins for pickup
 * @author shahzad
 */
public class Goldcoin extends StaticBody {
    private static SoundClip pickup;
    /**
     * sound to play when pick up
     */
    static {
        try {
           pickup = new SoundClip("data/CoinPickUp.mp3");
         } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
           System.out.println(e);
         }        
    }
    /**
     * creating the fixture for the coin
     * adding image to the fixture
     * @param w 
     */
    public Goldcoin(World w){
        super(w);
        Shape topCoinShape = new PolygonShape(-0.1f,1.19f, -0.53f,1.06f, -0.83f,
                0.85f, -1.05f,0.54f, -1.17f,0.06f, 1.18f,0.06f, 1.08f,0.52f, 
                0.77f,0.93f);
        Fixture topfixture = new SolidFixture(this, topCoinShape);
        Shape bottomCoinShape = new PolygonShape(-1.16f,0.02f, 1.17f,0.03f, 
                1.01f,-0.57f, 0.66f,-0.95f, 0.19f,-1.13f, -0.22f,-1.12f, 
                -0.82f,-0.81f, -1.11f,-0.31f);
        Fixture bottomfixture = new SolidFixture(this, bottomCoinShape);
        addImage(new BodyImage("data/Goldcoin.png", 1.5f));
        }
    /**
     * when the coin is picked up 
     * the object is destroyed
     * then sound will be played
     */
    @Override
    public void destroy(){
    pickup.play();
    super.destroy();
    }
}