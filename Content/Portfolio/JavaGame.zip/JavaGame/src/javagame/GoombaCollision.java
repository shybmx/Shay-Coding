package javagame;

import city.cs.engine.*;
/**
 * Adding the collision Listener for the man and the Goomba
 * @author shahzad
 */
public class GoombaCollision implements CollisionListener {
    private Man man; 
    /**
     * Giving the parameter for the man
     * @param man 
     */
    public GoombaCollision(Man man){
        this.man = man;
    }
    /**
     * if the Man collide with Goomba, Goomba gets destroyed
     * the Mans life count goes down by one
     * @param e 
     */
    public void collide(CollisionEvent e){
        if(e.getOtherBody() == man){
           man.decremnetCount();
           e.getReportingBody().destroy();
        }
    }
}