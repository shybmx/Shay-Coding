package javagame;

import city.cs.engine.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
/**
 * creating the Player or man
 * has fixture for player
 * has all images for different key press
 * hold coin and life count
 * @author shahzad
 */
public class Man extends Walker {
    private int GoldcoinCount; 
    private int life;
    private static SoundClip death;
    private static final Shape shape = new PolygonShape(-0.56f,0.74f, -0.99f,-0.12f, 
                    -1.1f,-1.28f, 1.11f,-1.26f, 0.98f,-0.12f, 0.67f,0.83f, 
                    0.25f,1.29f, -0.04f,1.28f);
     static {
        try {
           death = new SoundClip("data/Death.mp3");
         } catch (UnsupportedAudioFileException|IOException|LineUnavailableException e) {
           System.out.println(e);
         }        
    }
    public static final BodyImage mR =
            new BodyImage("data/CharacterRight.png", 3.0f);
    public static final BodyImage mL = 
              new BodyImage("data/CharacterLeft.png", 3.0f);
    public static final BodyImage mWR = 
              new BodyImage("data/WalkingRight.gif", 3.2f);
    public static final BodyImage mWL =
                new BodyImage ("data/WalkingLeft.gif", 3.2f);
    public static final BodyImage mJL =
               new BodyImage ("data/JumpLeft.png", 3.0f);
    public static final BodyImage mJR = 
               new BodyImage ("data/JumpRight.png", 3.0f);
    /**
     * give the man starting image and fixture
     * set life and coin count
     * @param world 
     */
    public Man(World world){  
            super(world, shape);
            addImage(mR);
            GoldcoinCount = 0;
            life = 3;
    }
    /**
     * return Gold coin count
     * @return 
     */
    public int goldcoinCount(){
        return GoldcoinCount;
     }
    /**
     * return the life count
     * @return 
     */
    public int lifeCount(){
        return life;
    }
    /**
     * increment coin count
     */
    public void incrementCount(){
    GoldcoinCount++;
    System.out.println("You now have: " + GoldcoinCount + " coins");
    }
    /**
     * decrement life count
     */
    public void decremnetCount(){
    life--;
    System.out.println("You now have: " + life + " Lifes");
    if(life == 0){
        System.out.println("You Are Dead!");
    }
   }
   /**
    * if life is 0 the player is dead
    */ 
   public void dead(){
     life = 0;
     System.out.println("You Are Dead!");
   } 
   /**
    * increment the life count
    */
   public void incrementCountHealth(){
    life++;
    System.out.println("You Gained Health");
    }
   /**
    * play sound when man is destroyed
    */
   @Override
    public void destroy(){
    death.play();
    super.destroy();
    }   
} 