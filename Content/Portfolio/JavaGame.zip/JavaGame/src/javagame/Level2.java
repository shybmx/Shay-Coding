package javagame;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
/**
 * Creating level 2
 * @author shahzad
 */
public class Level2 extends GameLevel{
    /**
     * populating the 2nd level
     * @param javagame 
     */
   @Override
    public void populate(JavaGame javagame) {
        super.populate(javagame);
        Shape floor = new BoxShape(37.5f, 4.5f);
        Shape wall = new BoxShape(0.5f, 27.5f);
        Shape stump = new BoxShape(0.5f, 2);
        Shape step = new BoxShape(2, 0.5f);
        Shape hurrdle = new BoxShape(0.5f, 0.25f);
        Shape floor1 = new BoxShape(5, 0.5f);
        Shape box = new BoxShape(0.5f, 0.5f);
        
        Body platform = new StaticBody(this, floor);
        platform.addImage(new BodyImage("data/floor.png", 9.1f));
        platform.setPosition(new Vec2(0,-23));
        
        Body platform1 = new StaticBody(this, wall);
        platform1.addImage(new BodyImage("data/wall.png", 35), new Vec2(0, -1));
        platform1.setPosition(new Vec2(-37.5f, 0));

        Body platform2 = new StaticBody(this, wall);
        platform2.addImage(new BodyImage("data/wall.png", 35), new Vec2(0, -1));
        platform2.setPosition(new Vec2(37.5f, 0));
        
        Body platform3 = new StaticBody(this, stump);
        platform3.addImage(new BodyImage("data/step3.png", 10), new Vec2(0, -2.9f));
        platform3.setPosition(new Vec2(-20, -16.5f));
        
        Body platform4 = new StaticBody(this, stump);
        platform4.addImage(new BodyImage("data/step3.png", 10), new Vec2(0, -2.9f));
        platform4.setPosition(new Vec2(0, -16.5f));
        
        Body platform5 = new StaticBody(this, step);
        platform5.addImage(new BodyImage("data/step1.png", 1.1f));
        platform5.setPosition(new Vec2(35, -12));
        
        Body platform6 = new StaticBody(this, floor1);
        platform6.addImage(new BodyImage("data/platform.png", 1.5f) );
        platform6.setPosition(new Vec2(25, -7.5f));
        
        Body platform7 = new StaticBody(this, floor1);
        platform7.addImage(new BodyImage("data/platform.png", 1.5f));
        platform7.setPosition(new Vec2(10, -5.5f));
        
        Body platform8 = new StaticBody(this, hurrdle);
        platform8.addImage(new BodyImage("data/stump.png", 0.5f));
        platform8.setPosition(new Vec2(23.5f, -14.5f));
        
        Body platform9 = new StaticBody(this, hurrdle);
        platform9.addImage(new BodyImage("data/stump.png", 0.5f));
        platform9.setPosition(new Vec2(-10 , -14.5f));
        
        Body platform10 = new StaticBody(this, hurrdle);
        platform10.addImage(new BodyImage("data/stump.png", 0.5f));
        platform10.setPosition(new Vec2(8, -14.5f));
        
        Body platform11 = new StaticBody(this, hurrdle);
        platform11.addImage(new BodyImage("data/stump.png", 0.5f));
        platform11.setPosition(new Vec2(17, -14.5f));
        
        Body platform12 = new StaticBody(this, floor1);
        platform12.addImage(new BodyImage("data/platform.png", 1.5f));
        platform12.setPosition(new Vec2(-6, -3.5f));
        
        Body platform13 = new StaticBody(this, floor1);
        platform13.addImage(new BodyImage("data/platform.png", 1.5f));
        platform13.setPosition(new Vec2(-23, -3.5f));
        
        Body platform14 = new StaticBody(this, step);
        platform14.addImage(new BodyImage("data/step1.png", 1.1f));
        platform14.setPosition(new Vec2(-35 , 0.5f));
        
        Body platform15 = new StaticBody(this, box);
        platform15.addImage(new BodyImage("data/box.png", 1.3f));
        platform15.setPosition(new Vec2(-30, 5));
        
        Body platform16 = new StaticBody(this, box);
        platform16.addImage(new BodyImage("data/box.png", 1.3f));
        platform16.setPosition(new Vec2(-20, 5));
        
        Body platform17 = new StaticBody(this, box);
        platform17.addImage(new BodyImage("data/box.png", 1.3f));
        platform17.setPosition(new Vec2(-15, 12));
        
        float i = -25;
        while (i < 30) {
            Spikes spikes = new Spikes(this);
            spikes.setPosition(new Vec2(i , -18));
            spikes.addCollisionListener(new SpikesCollision(getMan()));
            i = i + 10;
        }
        
        
        float x = -13;
        while(x < 30){
            Spikes spikes = new Spikes(this);
            spikes.setPosition(new Vec2(x, 5.5f));
            spikes.addCollisionListener(new SpikesCollision(getMan()));
            spikes.setAngleDegrees(180);
            x = x + 10;
        }
               
        Spikes spikes = new Spikes(this);
        spikes.setPosition(new Vec2(-25, 5));
        spikes.addCollisionListener(new SpikesCollision(getMan()));
        
        
        Safe safe = new Safe(this);
        safe.setPosition(new Vec2(-25, -10));
        
        Safe safe1 = new Safe(this);
        safe1.setPosition(new Vec2(-18,-7));
        
        Safe safe2 = new Safe(this);
        safe2.setPosition(new Vec2(2, -7));
        
        Safe safe3 = new Safe(this);
        safe3.setPosition(new Vec2(-25, 7));
        
        Button button = new Button(this);
        button.setPosition(new Vec2(-18, -10));
        button.addCollisionListener(new ButtonCollision(getMan()));
        
        Button button1 = new Button(this);
        button1.setPosition(new Vec2(2,-10));
        button1.addCollisionListener(new ButtonCollision(getMan()));
        
        Goldcoin coin = new Goldcoin(this);
        coin.setPosition(new Vec2(-10, -12));
        coin.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin1 = new Goldcoin(this);
        coin1.setPosition(new Vec2(8 ,-12));
        coin1.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin2 = new Goldcoin(this);
        coin2.setPosition(new Vec2(17, -12));
        coin2.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin3 = new Goldcoin(this);
        coin3.setPosition(new Vec2(23.5f , -12));
        coin3.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin4 = new Goldcoin(this);
        coin4.setPosition(new Vec2(17, -7));
        coin4.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin5 = new Goldcoin(this);
        coin5.setPosition(new Vec2(2, -5));
        coin5.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin6 = new Goldcoin(this);
        coin6.setPosition(new Vec2(0, -5));
        coin6.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin7 = new Goldcoin(this);
        coin7.setPosition(new Vec2(-15, -5));
        coin7.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin8 = new Goldcoin(this);
        coin8.setPosition(new Vec2(-5, 4));
        coin8.addCollisionListener(new CollectCoin(getMan()));
        
        Health health = new Health(this);
        health.setPosition(new Vec2(0, 20));
        health.addCollisionListener(new HealthPickUp(getMan()));
    }
    /**
     * setting the start position for man
     * @return 
     */
    @Override
    public Vec2 startPosition() {
         return new Vec2(-35, -17);
    }
    /**
     * setting position for gate
     * @return 
     */
    @Override
    public Vec2 gatePosition() {
   return new Vec2(-15, 20);
    }   
}