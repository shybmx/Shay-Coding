package javagame;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
/**
Creating the bonus Level
*/
public class BounsLevel extends GameLevel {

    /**
    Populate the Level with Objects
    */
    @Override
    public void populate(JavaGame javagame){
        super.populate(javagame);
        Shape floor = new BoxShape(37.5f, 4.5f);
        Shape wall = new BoxShape(0.5f, 27.5f);
        
        Body platform = new StaticBody(this, floor);
        platform.addImage(new BodyImage("data/floor.png", 9.1f));
        platform.setPosition(new Vec2(0,-23));
        
        Body platform1 = new StaticBody(this, wall);
        platform1.addImage(new BodyImage("data/wall.png", 35), new Vec2(0, -1));
        platform1.setPosition(new Vec2(-37.5f, 0));

        Body platform2 = new StaticBody(this, wall);
        platform2.addImage(new BodyImage("data/wall.png", 35), new Vec2(0, -1));
        platform2.setPosition(new Vec2(37.5f, 0));
        
        Goldcoin coin = new Goldcoin(this);
        coin.setPosition(new Vec2(-30, -10));
        coin.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin1 = new Goldcoin(this);
        coin1.setPosition(new Vec2(-30, -11.5f));
        coin1.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin2 = new Goldcoin(this);
        coin2.setPosition(new Vec2(-30, -13));
        coin2.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin3 = new Goldcoin(this);
        coin3.setPosition(new Vec2(-30, -14.5f));
        coin3.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin4 = new Goldcoin(this);
        coin4.setPosition(new Vec2(-28.5f, -10));
        coin4.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin5 = new Goldcoin(this);
        coin5.setPosition(new Vec2(-27f, -10));
        coin5.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin6 = new Goldcoin(this);
        coin6.setPosition(new Vec2(-25.5f, -11.5f));
        coin6.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin7 = new Goldcoin(this);
        coin7.setPosition(new Vec2(-28.5f, -10));
        coin7.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin8 = new Goldcoin(this);
        coin8.setPosition(new Vec2(-30, -16));
        coin8.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin9 = new Goldcoin(this);
        coin9.setPosition(new Vec2(-28.5f, -13));
        coin9.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin10 = new Goldcoin(this);
        coin10.setPosition(new Vec2(-27, -13));
        coin10.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin11 = new Goldcoin(this);
        coin11.setPosition(new Vec2(-25.5f, -14.5f));
        coin11.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin12 = new Goldcoin(this);
        coin12.setPosition(new Vec2(-25.5f, -16));
        coin12.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin13 = new Goldcoin(this);
        coin13.setPosition(new Vec2(-28.5f, -16));
        coin13.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin14 = new Goldcoin(this);
        coin14.setPosition(new Vec2(-27f, -16));
        coin14.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin15 = new Goldcoin(this);
        coin15.setPosition(new Vec2(-20, -10.5f));
        coin15.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin16 = new Goldcoin(this);
        coin16.setPosition(new Vec2(-20, -12));
        coin16.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin17 = new Goldcoin(this);
        coin17.setPosition(new Vec2(-20, -13.5f));
        coin17.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin18 = new Goldcoin(this);
        coin18.setPosition(new Vec2(-18.5f, -10));
        coin18.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin19 = new Goldcoin(this);
        coin19.setPosition(new Vec2(-17, -10));
        coin19.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin20 = new Goldcoin(this);
        coin20.setPosition(new Vec2(-15.5f, -10));
        coin20.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin21 = new Goldcoin(this);
        coin21.setPosition(new Vec2(-28.5f, -10));
        coin21.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin22 = new Goldcoin(this);
        coin22.setPosition(new Vec2(-18.5f, -15.5f));
        coin22.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin23 = new Goldcoin(this);
        coin23.setPosition(new Vec2(-17, -15.5f));
        coin23.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin24 = new Goldcoin(this);
        coin24.setPosition(new Vec2(-15.5f, -15.5f));
        coin24.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin25 = new Goldcoin(this);
        coin25.setPosition(new Vec2(-20, -15));
        coin25.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin26 = new Goldcoin(this);
        coin26.setPosition(new Vec2(-14, -15));
        coin26.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin27 = new Goldcoin(this);
        coin27.setPosition(new Vec2(-14, -13.5f));
        coin27.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin28 = new Goldcoin(this);
        coin28.setPosition(new Vec2(-14, -12));
        coin28.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin29 = new Goldcoin(this);
        coin29.setPosition(new Vec2(-14, -10.5f));
        coin29.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin30 = new Goldcoin(this);
        coin30.setPosition(new Vec2(-10, -10));
        coin30.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin31 = new Goldcoin(this);
        coin31.setPosition(new Vec2(-10, -11.5f));
        coin31.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin32 = new Goldcoin(this);
        coin32.setPosition(new Vec2(-10, -13));
        coin32.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin33 = new Goldcoin(this);
        coin33.setPosition(new Vec2(-10, -14.5f));
        coin33.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin34 = new Goldcoin(this);
        coin34.setPosition(new Vec2(-9, -15.5f));
        coin34.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin35 = new Goldcoin(this);
        coin35.setPosition(new Vec2(-7.5f, -15.5f));
        coin35.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin36 = new Goldcoin(this);
        coin36.setPosition(new Vec2(-6, -15.5f));
        coin36.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin37 = new Goldcoin(this);
        coin37.setPosition(new Vec2(-7.5f, -15.5f));
        coin37.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin38 = new Goldcoin(this);
        coin38.setPosition(new Vec2(-5, -14.5f));
        coin38.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin39 = new Goldcoin(this);
        coin39.setPosition(new Vec2(-5, -13));
        coin39.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin40 = new Goldcoin(this);
        coin40.setPosition(new Vec2(-5, -11.5f));
        coin40.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin41 = new Goldcoin(this);
        coin41.setPosition(new Vec2(-5, -10));
        coin41.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin42 = new Goldcoin(this);
        coin42.setPosition(new Vec2(0, -10));
        coin42.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin43 = new Goldcoin(this);
        coin43.setPosition(new Vec2(0, -11.5f));
        coin43.addCollisionListener(new CollectCoin(getMan()));
         
        Goldcoin coin44 = new Goldcoin(this);
        coin44.setPosition(new Vec2(0, -13));
        coin44.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin45 = new Goldcoin(this);
        coin45.setPosition(new Vec2(0, -14.5f));
        coin45.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin46 = new Goldcoin(this);
        coin46.setPosition(new Vec2(1.5f, -11.5f));
        coin46.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin47 = new Goldcoin(this);
        coin47.setPosition(new Vec2(3, -13));
        coin47.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin48 = new Goldcoin(this);
        coin48.setPosition(new Vec2(4.5f, -14.5f));
        coin48.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin50 = new Goldcoin(this);
        coin50.setPosition(new Vec2(4.5f, -13));
        coin50.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin51 = new Goldcoin(this);
        coin51.setPosition(new Vec2(4.5f, -11.5f));
        coin51.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin52 = new Goldcoin(this);
        coin52.setPosition(new Vec2(4.5f, -10));
        coin52.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin53 = new Goldcoin(this);
        coin53.setPosition(new Vec2(10, -10));
        coin53.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin54 = new Goldcoin(this);
        coin54.setPosition(new Vec2(10, -11.5f));
        coin54.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin55 = new Goldcoin(this);
        coin55.setPosition(new Vec2(11.5f, -9.5f));
        coin55.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin56 = new Goldcoin(this);
        coin56.setPosition(new Vec2(13, -9.5f));
        coin56.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin57 = new Goldcoin(this);
        coin57.setPosition(new Vec2(14.5f, -9.5f));
        coin57.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin58 = new Goldcoin(this);
        coin58.setPosition(new Vec2(14.5f, -12));
        coin58.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin59 = new Goldcoin(this);
        coin59.setPosition(new Vec2(13, -12));
        coin59.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin60 = new Goldcoin(this);
        coin60.setPosition(new Vec2(11.5f, -12));
        coin60.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin61 = new Goldcoin(this);
        coin61.setPosition(new Vec2(15.5f, -13.5f));
        coin61.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin62 = new Goldcoin(this);
        coin62.setPosition(new Vec2(15.5f, -15));
        coin62.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin63 = new Goldcoin(this);
        coin63.setPosition(new Vec2(14.5f, -15.5f));
        coin63.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin64 = new Goldcoin(this);
        coin64.setPosition(new Vec2(13, -15.5f));
        coin64.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin65 = new Goldcoin(this);
        coin65.setPosition(new Vec2(11.5f, -15.5f));
        coin65.addCollisionListener(new CollectCoin(getMan()));
        
        Goldcoin coin66 = new Goldcoin(this);
        coin66.setPosition(new Vec2(10, -15.5f));
        coin66.addCollisionListener(new CollectCoin(getMan()));
    }
    
    /**
    Starting Position for the character
    */
    @Override
    public Vec2 startPosition() {
        return new Vec2(-35, -17);
    }

    /**
    Position for end goal
    */
    @Override
    public Vec2 gatePosition() {
        return new Vec2(30, -10);
    }
    
}