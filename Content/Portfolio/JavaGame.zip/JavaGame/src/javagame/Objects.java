package javagame;

import city.cs.engine.*;
/**
 * objects
 * @author shahzad
 */
public class Objects extends World {
    private Man man;
    /**
     * objects
     */
    public Objects(){
    super();
        
     }    
    /**
     * return man
     * @return 
     */
    public Man getMan(){
    return man;
   }
}