package javagame;

import city.cs.engine.*;
/**
 * Button Collision
 * @author shahzad
 */
public class ButtonCollision implements CollisionListener{
    private Man man;
    /**
     * Setting Parameter for the man to collide 
     * @param man 
     */
    public ButtonCollision(Man man){
        this.man = man;
    }
    /**
     * What happens when man and button collide
     * @param e 
     */
   @Override
   public void collide(CollisionEvent e){
      if(e.getOtherBody() == man){
         e.getReportingBody().destroy();
      }
   }
}
