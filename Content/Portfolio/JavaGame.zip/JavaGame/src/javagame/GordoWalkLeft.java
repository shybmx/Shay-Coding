package javagame;

import fsm.FSMState;
/**
 * Make the Gordo Walk Left
 * @author shahzad
 */
public class GordoWalkLeft extends FSMState<GordoSpikes>{
    /**
     * If man is on the right hand side walk right
     */
    protected void update() {
        GordoSpikes gordo = getContext();
      if(gordo.inRangeRight()){
          gotoState(new GordoWalkRight());
      }else if (!gordo.inRange()){
          gotoState(new GordoStandStill());
      }else {
          gordo.startWalking(-2);
      }
    }
    /**
     * get the context
     */
    protected void enter() {
        GordoSpikes gordo = getContext();
    }

    protected void exit() {   
    }   
}