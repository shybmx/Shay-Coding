package javagame;

import fsm.FSMState;
/**
 * When Man is on the left walk right
 * @author shahzad
 */
public class WalkLeft extends FSMState<Goomba>{
    /**
     * update the movement
     */
    protected void update() {
       Goomba goomba = getContext();
      if(goomba.inRangeRight()){
          gotoState(new WalkRight());
      }else if (!goomba.inRange()){
          gotoState(new StandStillState());
      }else {
          goomba.startWalking(2);
      }
    }
    /**
     * get context
     */
    protected void enter() {
        Goomba gooma = getContext();
    }

    protected void exit() {}    
}