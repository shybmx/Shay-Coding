package javagame;

import fsm.FSMState;
import org.jbox2d.common.Vec2;
/** 
 * Goomba Stand still state
 * @author shahzad
 */
class StandStillState extends FSMState<Goomba> {

    public StandStillState() {
    }
    /**
     * Update Goomba if man is on left or right hand side
     */
    protected void update() {
       Goomba goomba = getContext();
       if(goomba.inRangeLeft()){
           gotoState(new WalkLeft());
       } else if (goomba.inRangeRight()){
           gotoState(new WalkRight());
       }
    }
    /**
     * get context 
     * change velocity and get new x and y
     */
    protected void enter() {
        Goomba goomba = getContext();
        goomba.setLinearVelocity(new Vec2());
    }
    
    protected void exit() {}   
}