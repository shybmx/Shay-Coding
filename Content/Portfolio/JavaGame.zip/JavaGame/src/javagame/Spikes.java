package javagame;

import city.cs.engine.*;
/**
 * creating spikes
 * @author shahzad
 */
public class Spikes extends StaticBody{
    /**
     * creating the spikes
     * @param w 
     */
    public Spikes(World w) {
        super(w);
        /**
         * giving the spikes fixtures and an image
         */
        Shape spikes = new PolygonShape(-5.167f,0.485f, 5.152f,0.5f, 
                5.182f,-0.53f, -5.167f,-0.515f);
        Fixture fixture = new SolidFixture(this, spikes);
        addImage(new BodyImage("data/Spikes.png", 1.0f));
    }
}