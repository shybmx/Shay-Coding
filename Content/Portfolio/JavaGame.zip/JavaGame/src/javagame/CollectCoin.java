package javagame;

import city.cs.engine.*;

/**
 * Unit Collision between man and coin
 * @author shahzad
 */
public class CollectCoin implements CollisionListener {
    private Man man;
    /**
     * set parameters
     * @param man 
     */
    public CollectCoin(Man man){
        this.man = man;
    }
    /**
     * if the man collide with coin the count goes up
     * @param c 
     */
    @Override
    public void collide(CollisionEvent c){
        if(c.getOtherBody() == man){
            man.incrementCount();
            c.getReportingBody().destroy();
        }    
    }
}