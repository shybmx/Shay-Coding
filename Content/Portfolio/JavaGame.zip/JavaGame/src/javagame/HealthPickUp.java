package javagame;

import city.cs.engine.*;
/**
 * When man Picks up health Collision Listener
 * @author shahzad
 */
public class HealthPickUp implements CollisionListener {
    private Man man;
    /**
     * Parameter for man
     * @param man 
     */
    public HealthPickUp(Man man){
        this.man = man;
    }
    /**
     * if man touches health 
     * man life increment
     * health item gets destoryed
     * @param e 
     */
    @Override
    public void collide(CollisionEvent e) {
        if(e.getOtherBody() == man){
          man.incrementCountHealth();
          e.getReportingBody().destroy();
        }
    } 
}