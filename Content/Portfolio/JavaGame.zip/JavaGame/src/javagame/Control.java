package javagame;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import java.awt.event.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
/**
 * adding keyListenr for input
 * @author shahzad
 */
public class Control extends KeyAdapter {
    private static final float Walking_Speed = 4;
    private static final float Jumping_Speed = 10;
    private SoundClip jump;
    private Walker man;
    /**
     * setting parameters
     * @param man 
     */    
    public Control(Walker man){
        this.man = man;
      }
    /**
     * this will listen to key pressed events 
     * @param w 
     */
    public void setbody(Walker w){
        this.man = w;
    }
       /**
        * what key is pressed they will go in that direction
        * remove an image and and another
        * if they jump it will also play a sound
        * @param b 
        */
       @Override
        public void keyPressed(KeyEvent b){
            int code = b.getKeyCode();
            if (code == KeyEvent.VK_A){
                man.removeImage(Man.mR);
                man.removeImage(Man.mL);
                man.removeImage(Man.mWR);
                man.removeImage(Man.mJL);
                man.removeImage(Man.mJR);
                man.addImage(Man.mWL);
                man.startWalking(-Walking_Speed);
          }
            else if(code == KeyEvent.VK_LEFT){
                man.removeImage(Man.mR);
                man.removeImage(Man.mL);
                man.removeImage(Man.mWR);
                man.removeImage(Man.mJL);
                man.removeImage(Man.mJR);
                man.addImage(Man.mWL);
                man.startWalking(-Walking_Speed);
          }
            else if(code == KeyEvent.VK_RIGHT){
                man.removeImage(Man.mR);
                man.removeImage(Man.mL);
                man.removeImage(Man.mWL);
                man.removeImage(Man.mJL);
                man.removeImage(Man.mJR);
                man.addImage(Man.mWR);
                man.startWalking(Walking_Speed);
            }
            else if (code == KeyEvent.VK_D){
                man.removeImage(Man.mR);
                man.removeImage(Man.mL);
                man.removeImage(Man.mWL);
                man.removeImage(Man.mJL);
                man.removeImage(Man.mJR);
                man.addImage(Man.mWR);
                man.startWalking(Walking_Speed);
          }
            else if (code == KeyEvent.VK_W) { 
                man.removeImage(Man.mR);
                man.removeImage(Man.mL);
                man.removeImage(Man.mWL);
                man.removeImage(Man.mJL);
                man.removeImage(Man.mJR);
                man.removeImage(Man.mWR);
                man.addImage(Man.mJR);
                try{
                    jump = new SoundClip("data/Jump.mp3");
                    jump.play();
                }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
                Vec2 v = man.getLinearVelocity();
            if (Math.abs(v.y) < 0.01f) {
                man.jump(Jumping_Speed);
                }
            }
            else if(code == KeyEvent.VK_SPACE){
                man.removeImage(Man.mR);
                man.removeImage(Man.mL);
                man.removeImage(Man.mWL);
                man.removeImage(Man.mJL);
                man.removeImage(Man.mJR);
                man.removeImage(Man.mWR);
                man.addImage(Man.mJR);
                try{
                    jump = new SoundClip("data/Jump.mp3");
                    jump.play();
                }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
                Vec2 v = man.getLinearVelocity();
            if (Math.abs(v.y) < 0.01f) {
                man.jump(Jumping_Speed);
                } 
            else{
                man.removeImage(Man.mL);
                man.removeImage(Man.mWL);
                man.removeImage(Man.mJL);
                man.removeImage(Man.mJR);
                man.removeImage(Man.mWR);
                man.addImage(Man.mR);
            }
            if (Math.abs(v.y) < 0.01f) {
                man.jump(Jumping_Speed);
                }
            }
            else if(code == KeyEvent.VK_UP){
                man.removeImage(Man.mR);
                man.removeImage(Man.mL);
                man.removeImage(Man.mWL);
                man.removeImage(Man.mJL);
                man.removeImage(Man.mJR);
                man.removeImage(Man.mWR);
                man.addImage(Man.mJR);
                try{
                    jump = new SoundClip("data/Jump.mp3");
                    jump.play();
                }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
                Vec2 v = man.getLinearVelocity();
            if (Math.abs(v.y) < 0.01f) {
                man.jump(Jumping_Speed);
                } 
            }
            
        /**
         * When key is released stop moving
         * remove image and add image
         */    
        }
       @Override
        public void keyReleased(KeyEvent b){
        int code = b.getKeyCode();
        //when the A key is realsed the character will stop moving
        if(code == KeyEvent.VK_A){
            man.removeImage(Man.mR);
            man.removeImage(Man.mJL);
            man.removeImage(Man.mJR);
            man.removeImage(Man.mWL);
            man.removeImage(Man.mWR);
            man.addImage(Man.mL);
            man.stopWalking();
        }
        //when the D key is realsed the character will stop moving
        else if(code == KeyEvent.VK_D){
            man.removeImage(Man.mL);
            man.removeImage(Man.mJL);
            man.removeImage(Man.mJR);
            man.removeImage(Man.mWL);
            man.removeImage(Man.mWR);
            man.addImage(Man.mR);
            man.stopWalking();
        }
        else if (code == KeyEvent.VK_LEFT){
            man.removeImage(Man.mR);
            man.removeImage(Man.mJL);
            man.removeImage(Man.mJR);
            man.removeImage(Man.mWL);
            man.removeImage(Man.mWR);
            man.addImage(Man.mL);
            man.stopWalking();
        }
        else if(code == KeyEvent.VK_RIGHT){
            man.removeImage(Man.mL);
            man.removeImage(Man.mJL);
            man.removeImage(Man.mJR);
            man.removeImage(Man.mWL);
            man.removeImage(Man.mWR);
            man.addImage(Man.mR);
            man.stopWalking();
        }
    }
}