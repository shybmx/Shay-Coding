package javagame;

import java.awt.Graphics2D;
import city.cs.engine.*;
import java.awt.Color;
/**
 * setting GUI for life and Health
 * @author shahzad
 */
public class CoinView extends MyView {
    private Man man;
    
    /**
     * Parameter for health and coin count
     * @param world
     * @param man
     * @param width
     * @param height 
     */
    public CoinView(World world, Man man, int width, int height) {
        super(world, width, height);
        this.man = man;
    }

    /**
     * drawing the GUI for life and coin count
     * @param g 
     */
    @Override
    protected void paintForeground(Graphics2D g) {
        g.setColor(Color.WHITE);
        g.drawString("You have: " + man.goldcoinCount() + " Coins", 10, 20);
        g.drawString(man.lifeCount() + " Lives Remaining", 10, 40);
        if(man.lifeCount() == 0){
            g.drawString("You Are Dead, Click Restart To Try Again", 0, 0);
        }
    }
 }