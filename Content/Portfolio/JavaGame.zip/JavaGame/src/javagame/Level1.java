package javagame;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
/**
 * Creating level 1
 * @author shahzad
 */
public class Level1 extends GameLevel {
    private JavaGame game;
    /**
     * populating the level
     * @param javagame 
     */
    @Override
    public void populate(JavaGame javagame) {
        super.populate(javagame);
        Shape floor = new BoxShape(37.5f, 4.5f);
        Shape box = new BoxShape(0.5f, 0.5f);
        Shape smallpole = new BoxShape(0.5f, 1.2f);
        Shape hiddenBox = new BoxShape(3, 0.5f);
        Shape floor1 = new BoxShape(20, 0.5f);
        Shape floor2 = new BoxShape(8.5f, 0.5f);
        Shape box1 = new BoxShape(1.5f, 0.5f);
        Shape wall = new BoxShape(0.5f, 27.5f);

        Body platform = new StaticBody(this, floor);
        platform.addImage(new BodyImage("data/floor.png", 9.1f));
        platform.setPosition(new Vec2(0, -23));

        Body platform1 = new StaticBody(this, smallpole);
        platform1.addImage(new BodyImage("data/step.png", 2.5f));
        platform1.setPosition(new Vec2(-15, -14));
       
        Body platform2 = new StaticBody(this, box);
        platform2.addImage(new BodyImage("data/box.png", 1.3f));
        platform2.setPosition(new Vec2(-3, -12f));

        Body platform3 = new StaticBody(this, box);
        platform3.addImage(new BodyImage("data/box.png", 1.3f));
        platform3.setPosition(new Vec2(4.5f, -8.5f));

        Body platform4 = new StaticBody(this, box);
        platform4.addImage(new BodyImage("data/box.png", 1.3f));
        platform4.setPosition(new Vec2(10, -5));

        Body platform5 = new StaticBody(this, hiddenBox);
        platform5.addImage(new BodyImage("data/platform1.png", 0.9f), new Vec2(0, 0.1f));
        platform5.setPosition(new Vec2(5, -0.5f));

        Body platform6 = new StaticBody(this, hiddenBox);
        platform6.addImage(new BodyImage("data/platform1.png", 0.9f), new Vec2(0, 0.1f));
        platform6.setPosition(new Vec2(14, -0.5f));

        Body platform7 = new StaticBody(this, floor1);
        platform7.addImage(new BodyImage("data/floor1.png", 1.8f));
        platform7.setPosition(new Vec2(9, 7));

        Body platform8 = new StaticBody(this, floor2);
        platform8.addImage(new BodyImage("data/floor2.png", 1.8f));
        platform8.setPosition(new Vec2(-28.5f, 7));

        Body platform9 = new StaticBody(this, wall);
        platform9.addImage(new BodyImage("data/wall.png", 35), new Vec2(0, -1));
        platform9.setPosition(new Vec2(-37.5f, 0));

        Body platform10 = new StaticBody(this, wall);
        platform10.addImage(new BodyImage("data/wall.png", 35), new Vec2(0, -1));
        platform10.setPosition(new Vec2(37.5f, 0));
        
        float i = -7.5f;
        while (i < 8) {
            Body platforms = new StaticBody(this, box1);
            platforms.addImage(new BodyImage("data/step1.png"));
            platforms.setPosition(new Vec2(29.5f, i));
            i = i + 8;
        }

        float x = -12;
        while (x < 10) {
            Body platforms1 = new StaticBody(this, box1);
            platforms1.addImage(new BodyImage("data/step1.png"));
            platforms1.setPosition(new Vec2(34.5f, x));
            x = x + 8.5f;
        }


        //Adding Safe
        Safe safe = new Safe(this);
        safe.setPosition(new Vec2(-20, -10));

        Safe safe1 = new Safe(this);
        safe1.setPosition(new Vec2(20, 25));

        Spikes spikes = new Spikes(this);
        spikes.setPosition(new Vec2(-15, 5.5f));
        spikes.addCollisionListener(new SpikesCollision(getMan()));

        // creating coins
        float y = 1;
        while (y < 18) {
            Goldcoin goldcoin = new Goldcoin(this);
            goldcoin.setPosition(new Vec2(y, 1.5f));
            goldcoin.addCollisionListener(new CollectCoin(getMan()));
            y = y + 1.5f;
        }

        float z = 1;
        while (z < 18) {
            Goldcoin goldcoin = new Goldcoin(this);
            goldcoin.setPosition(new Vec2(z, 3));
            goldcoin.addCollisionListener(new CollectCoin(getMan()));
            z = z + 1.5f;
        }
        float w = 1;
        while (w < 18) {
            Goldcoin goldcoin = new Goldcoin(this);
            goldcoin.setPosition(new Vec2(w, 4.5f));
            goldcoin.addCollisionListener(new CollectCoin(getMan()));
            w = w + 1.5f;
        }

        Goldcoin goldcoin = new Goldcoin(this);
        goldcoin.setPosition(new Vec2(-25, -17));
        //making the coin collide with the character
        goldcoin.addCollisionListener(new CollectCoin(getMan()));
        
        GordoSpikes emeny = new GordoSpikes(this);
        emeny.setPosition(new Vec2(-5, 0));      
        emeny.addCollisionListener(new SpikesCollision(getMan()));
        
        y = 15;
        while(y < 10){
            emeny.setPosition(new Vec2(-5, y = y + 1));
            emeny.addCollisionListener(new SpikesCollision(getMan()));
        }
        
        Health health = new Health(this);
        health.setPosition(new Vec2(0, 20));
        health.addCollisionListener(new HealthPickUp(getMan()));
    }
    /**
     * set the gate position for this level
     * @return 
     */
    @Override
    public Vec2 gatePosition() {
        return new Vec2(-35, 13); 
    }
    /**
     * set starting position for Player
     * @return 
     */
    @Override
    public Vec2 startPosition() {
        return new Vec2(-30, -17);
    }
}