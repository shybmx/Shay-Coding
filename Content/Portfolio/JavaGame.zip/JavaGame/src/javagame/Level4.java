package javagame;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import java.util.*;
/**
 * creating level 4
 * @author shahzad
 */
public class Level4 extends GameLevel {
    /**
     * populating level 4 with object
     * @param javagame 
     */
    @Override
    public void populate(JavaGame javagame){
        super.populate(javagame);
        Shape box = new BoxShape(0.5f, 0.5f);
        Random r = new Random();
        int number;
        
        Body platform = new StaticBody(this, box);
        platform.addImage(new BodyImage("data/box.png", 1.3f));
        platform.setPosition(new Vec2(0, 25));
        
        int i = -150; 
        while(i < 40){
        Spikes spikesleft = new Spikes(this);
        spikesleft.setPosition(new Vec2(-10 , i));
        spikesleft.setAngleDegrees(270);
        spikesleft.addCollisionListener(new SpikesCollision(getMan()));
        i = i + 10;
        }
        
        int x = -150;
        while(x < 40){
        Spikes spikesright = new Spikes(this);
        spikesright.setPosition(new Vec2(10, x));
        spikesright.setAngleDegrees(90);
        spikesright.addCollisionListener(new SpikesCollision(getMan()));
        x = x + 10;
        }
        
        int y = -5;
        while(y < 10){
        Spikes groundspikes = new Spikes(this);
        groundspikes.setPosition(new Vec2(y, -155));
        groundspikes.addCollisionListener(new SpikesCollision(getMan()));
        y = y + 10;
        }
        
        int z = 0;
        while(z < 50){
        Goldcoin coins = new Goldcoin(this);
        coins.setPosition(new Vec2(-r.nextInt(8), -r.nextInt(150)));
        coins.addCollisionListener(new CollectCoin(getMan()));
        z++;
        }
    }
    /**
     * setting start position for man for this level
     * @return 
     */
    @Override
    public Vec2 startPosition() {
      return new Vec2(0, 30);
    }
    /**
     * setting gate position for this level
     * @return 
     */
    @Override
    public Vec2 gatePosition() {
      return new Vec2(0, -155);  
    } 
}