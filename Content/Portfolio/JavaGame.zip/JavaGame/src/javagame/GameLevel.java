package javagame;

import org.jbox2d.common.Vec2;
import city.cs.engine.*;
/**
 * where the game is created
 * @author shahzad
 */
public abstract class GameLevel extends World{
    protected Man man;
    protected Gate gate;
    protected Safe safe;
/**
 * every level will be populate with these
 * @param javagame 
 */
public void populate(JavaGame javagame){
    man = new Man(this);
    man.setPosition(startPosition());
    gate = new Gate (this);
    gate.setPosition(gatePosition());
    gate.addCollisionListener(new GateCollision(javagame));
}
/**
 * abstract method for the start position of man
 * @return 
 */
public abstract Vec2 startPosition();
/**
 * return man
 * @return 
 */
public Man getMan(){
    return man;
}
/**
 * return box/safe
 * @return 
 */
public Safe getSafe(){
    return safe;
}
/**
 * abstract method for the gate position
 * @return 
 */
public abstract Vec2 gatePosition();    
}