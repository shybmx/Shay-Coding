package javagame;

import city.cs.engine.*;
/**
 * creating the shape for the gate
 * @author shahzad
 */
public class Gate extends StaticBody {
    public static final Shape shape = new BoxShape(1, 1);
    /**
     * setting the gate in the world
     * adding an image on the gate
     * @param w 
     */
    public Gate(World w) {
        super(w, shape);
        addImage(new BodyImage("data/EndBox.png", 2.0f));
    }
    
}
