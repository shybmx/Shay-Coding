package javagame;

import city.cs.engine.*;
import java.io.*;
import java.util.*;
import javax.sound.sampled.*;

/**
 * Adding GUI to the main game
 * @author shahzad
 */
public final class ControlPanel extends javax.swing.JPanel {
    private JavaGame game;
    public SoundClip music;
    private ArrayList<String> tracks;
    private int i;
    /**
     * adding all the tracks and starting music
     * adding it to main game
     * @param game 
     */
    public ControlPanel(JavaGame game) {
        this.game = game;
        initComponents();
        tracks = new ArrayList<String>();
        tracks.add("data/Level1.mp3");
        tracks.add("data/Level2.mp3");
        tracks.add("data/Level3.mp3");
        tracks.add("data/Level4.mp3");
        tracks.add("data/Level5.mp3");
        tracks.add("data/Level6.mp3");
        tracks.add("data/Level7.mp3");
        tracks.add("data/Level8.mp3");
        tracks.add("data/Level9.mp3");
        tracks.add("data/Level10.mp3");
        tracks.add("data/Level11.mp3");
        tracks.add("data/Level12.mp3");
        tracks.add("data/Level13.mp3");
        tracks.add("data/Level14.mp3");
        tracks.add("data/Level15.mp3");
        tracks.add("data/Level16.mp3");
        tracks.add("data/Level17.mp3");
        tracks.add("data/Level18.mp3");
        tracks.add("data/Level19.mp3");
        tracks.add("data/Level20.mp3");
        i = 0;
        try{
          music = new SoundClip(tracks.get(i));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        restart = new javax.swing.JButton();
        quitToMenu = new javax.swing.JButton();
        mute = new javax.swing.JButton();
        unMute = new javax.swing.JButton();
        pause = new javax.swing.JButton();
        resume = new javax.swing.JButton();
        nextSong = new javax.swing.JButton();
        prevSong = new javax.swing.JButton();

        restart.setText("Restart");
        restart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                restartActionPerformed(evt);
            }
        });

        quitToMenu.setText("Quit to Menu");
        quitToMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quitToMenuActionPerformed(evt);
            }
        });

        mute.setText("Mute");
        mute.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                muteActionPerformed(evt);
            }
        });

        unMute.setText("Unmute");
        unMute.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unMuteActionPerformed(evt);
            }
        });

        pause.setText("║");
        pause.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pauseActionPerformed(evt);
            }
        });

        resume.setText("►");
        resume.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resumeActionPerformed(evt);
            }
        });

        nextSong.setText("Next Song ►");
        nextSong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextSongActionPerformed(evt);
            }
        });

        prevSong.setText("◄Previous Song");
        prevSong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevSongActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(resume)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pause)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mute)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(unMute)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(quitToMenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(restart)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(prevSong, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nextSong))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(quitToMenu)
                .addComponent(restart)
                .addComponent(mute)
                .addComponent(unMute)
                .addComponent(pause)
                .addComponent(resume)
                .addComponent(nextSong)
                .addComponent(prevSong))
        );
    }// </editor-fold>//GEN-END:initComponents
    /**
     * restart the game
     * @param evt 
     */
    private void restartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restartActionPerformed
        game.frame.dispose();
        game.frame.repaint();
        music.stop();
        new JavaGame();
    }//GEN-LAST:event_restartActionPerformed
    /**
     * quit back to the main menu
     * @param evt 
     */
    private void quitToMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quitToMenuActionPerformed
        //For Quit
        game.frame.dispose();
        music.stop();
    }//GEN-LAST:event_quitToMenuActionPerformed
    /**
     * pause the game
     * @param evt 
     */
    private void pauseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pauseActionPerformed
      game.getWorld().stop();
      music.pause();
    }//GEN-LAST:event_pauseActionPerformed
    /**
     * after pause, continue the game
     * @param evt 
     */
    private void resumeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resumeActionPerformed
       game.getWorld().start();
       music.resume();
    }//GEN-LAST:event_resumeActionPerformed
    /**
     * pauses the music.
     * @param evt 
     */
    private void unMuteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unMuteActionPerformed
        music.resume();
    }//GEN-LAST:event_unMuteActionPerformed
    /**
     * resume the music after pause
     * @param evt 
     */
    private void muteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_muteActionPerformed
        music.pause();
    }//GEN-LAST:event_muteActionPerformed
    /**
     * moves onto the next track in ArrayList
     * @param evt 
     */
    private void nextSongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextSongActionPerformed
       music.stop();
       i++;
       try{
          music = new SoundClip(tracks.get(i));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
       System.out.println("Song Changing: " + i);
       music.play();
    }//GEN-LAST:event_nextSongActionPerformed
    /**
     * moves onto previous track in ArrayList
     * @param evt 
     */
    private void prevSongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevSongActionPerformed
       music.stop();
       i--;
       try{
          music = new SoundClip(tracks.get(i));
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
       System.out.println("Song Changing: " + i);
       music.play();
    }//GEN-LAST:event_prevSongActionPerformed
/**
 * returns the music
 * @return 
 */
public SoundClip getMusic(){
    return music;
}    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton mute;
    private javax.swing.JButton nextSong;
    private javax.swing.JButton pause;
    private javax.swing.JButton prevSong;
    private javax.swing.JButton quitToMenu;
    private javax.swing.JButton restart;
    private javax.swing.JButton resume;
    private javax.swing.JButton unMute;
    // End of variables declaration//GEN-END:variables
}