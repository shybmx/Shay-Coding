package javagame;

import city.cs.engine.*;
import fsm.FSM;
/**
 * Parameters for fixture, images, range for character
 * @author shahzad
 */
public class GordoSpikes extends Walker implements StepListener{
    private static final Shape gordoSpikes = new PolygonShape(-0.016f,0.971f, -0.699f,0.699f,
                -0.985f,0.005f, -0.684f,-0.695f, -0.005f,-0.971f, 0.699f,-0.699f, 
                0.978f,-0.013f, 0.702f,0.681f);
    private static final BodyImage gordoi = new BodyImage ("data/Gordospikes.png", 2.0f);
    private Level1 level1;
    private static final float range = 5;
    private final FSM<GordoSpikes> fsm;
    /**
     * adding fixture and image
     * leaving him in stand still state if Man is not in range
     * @param level1 
     */
    public GordoSpikes(Level1 level1){
        super(level1, gordoSpikes); 
        this.level1 = level1;
        Fixture gordoFixture = new SolidFixture(this, gordoSpikes);
        addImage(gordoi);
        fsm = new FSM<GordoSpikes>(this, new GordoStandStill());
        level1.addStepListener(this);
    }
    /**
     * if man is on left hand side
     * @return 
     */
    public boolean inRangeLeft(){
        Body a = level1.getMan();
        float gap = getPosition().x - a.getPosition().x;
        return gap < range && gap > 0;
    }
    /**
     * if man is on right hand side
     * @return 
     */
    public boolean inRangeRight() {
        Body a = level1.getMan();
        float gap = getPosition().x - a.getPosition().x;
        return gap > -range && gap < 0;
    }
    /**
     * if the man is in range of both left and right hand side
     * @return 
     */
    public boolean inRange() {
        return inRangeLeft() || inRangeRight();
    }
    /**
     * Update the FSM 
     * @param e 
     */
    public void preStep(StepEvent e) {
        fsm.update();
    }

    @Override
    public void postStep(StepEvent e) {  
    }   
}