package javagame;

import city.cs.engine.*;
import java.io.IOException;
import javax.sound.sampled.*;
/**
 * The start Menu
 * @author shahzad
 */
public class StartMenu extends javax.swing.JFrame {
    private SoundClip music; 
    /**
     * setting the size 
     * start menu music
     */
    public StartMenu() {
        initComponents();
        this.setSize(764, 690);  
        this.setResizable(false);
        try{
          music = new SoundClip("data/StartMenu.mp3");
          music.loop();
      }catch(UnsupportedAudioFileException|IOException|LineUnavailableException e) {
            System.out.println(e);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        start = new javax.swing.JButton();
        quitgame = new javax.swing.JButton();
        control = new javax.swing.JButton();
        soundTrack = new javax.swing.JButton();
        backGround = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImages(null);
        getContentPane().setLayout(null);

        start.setText("Start");
        start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startActionPerformed(evt);
            }
        });
        getContentPane().add(start);
        start.setBounds(100, 400, 100, 28);

        quitgame.setText("Quit Game");
        quitgame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quitgameActionPerformed(evt);
            }
        });
        getContentPane().add(quitgame);
        quitgame.setBounds(100, 490, 100, 28);

        control.setText("Controls");
        control.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                controlActionPerformed(evt);
            }
        });
        getContentPane().add(control);
        control.setBounds(100, 430, 100, 28);

        soundTrack.setText("Sound Track");
        soundTrack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                soundTrackActionPerformed(evt);
            }
        });
        getContentPane().add(soundTrack);
        soundTrack.setBounds(100, 460, 100, 28);

        backGround.setIcon(new javax.swing.ImageIcon("C:\\Users\\shahzad\\Documents\\City univeristy\\Year 1\\Java Lab\\CourseWork\\JavaGame\\data\\MenuBackGround.jpg")); // NOI18N
        getContentPane().add(backGround);
        backGround.setBounds(0, 0, 760, 660);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * start the game
     * @param evt 
     */
    private void startActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startActionPerformed
        music.stop();
        new JavaGame();
    }//GEN-LAST:event_startActionPerformed
    /**
     * quit the whole system
     * @param evt 
     */
    private void quitgameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quitgameActionPerformed
       System.exit(0);
    }//GEN-LAST:event_quitgameActionPerformed
    /**
     * Show the control menu
     * @param evt 
     */
    private void controlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_controlActionPerformed
        new ControlView();
    }//GEN-LAST:event_controlActionPerformed
    /**
     * Show sound track menu
     * @param evt 
     */
    private void soundTrackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_soundTrackActionPerformed
        music.stop();
        new SoundTrack();
    }//GEN-LAST:event_soundTrackActionPerformed
    /**
     * Start the start menu
     * @param args 
     */
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StartMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StartMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StartMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StartMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StartMenu().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backGround;
    private javax.swing.JButton control;
    private javax.swing.JButton quitgame;
    private javax.swing.JButton soundTrack;
    private javax.swing.JButton start;
    // End of variables declaration//GEN-END:variables
}