package javagame;
/**
 * Allow the player to see the controls
 * @author shahzad
 */
public class ControlView extends javax.swing.JFrame {
    /**
     * setting the size
     * setting visibility
     * Cannot be resized
     */
    public ControlView() {
        initComponents();
        this.setSize(764, 690);
        this.setResizable(false);
        this.setLocationByPlatform(true);
        this.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        backToMenu = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        backToMenu.setText("Back to Menu");
        backToMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToMenuActionPerformed(evt);
            }
        });
        getContentPane().add(backToMenu);
        backToMenu.setBounds(560, 90, 110, 28);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\shahzad\\Documents\\City univeristy\\Year 1\\Java Lab\\CourseWork\\JavaGame\\data\\Control.jpg")); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 764, 710);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * goes back to the menu
     * @param evt 
     */
    private void backToMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToMenuActionPerformed
        this.dispose();
    }//GEN-LAST:event_backToMenuActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backToMenu;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}