package javagame;

import city.cs.engine.*;
/**
Adding a destructible button
*/
public class Button extends StaticBody{
    /**
    Creating button shape
    */
   public Button(World w){
       super(w);
       Shape button1 = new PolygonShape(-0.674f,0.5f, -0.678f,-0.498f, 
               0.674f,-0.5f, 0.676f,0.5f);
       Fixture fixture1 = new SolidFixture(this, button1); 
       addImage(new BodyImage("data/Button.png", 1.0f));      
   }
}