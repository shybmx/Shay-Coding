package javagame;

import fsm.FSMState;
/**
 * when man is on left walk right
 * @author shahzad
 */
class WalkRight extends FSMState<Goomba>{
    /**
     * update the Goomba
     */
    protected void update() {
        Goomba goomba = getContext();
        if (goomba.inRangeLeft()) {
            gotoState(new WalkLeft());
        } else if (!goomba.inRange()) {
            gotoState(new StandStillState());
        } else {
            goomba.startWalking(- 2);
        }
    }

    protected void enter() {
        Goomba goomba = getContext();
    }
    
    protected void exit() {}
}