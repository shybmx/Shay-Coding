package javagame;

import fsm.FSMState;
import org.jbox2d.common.*;
/**
 * making the Gordo Stand Still
 * @author shahzad
 */
public class GordoStandStill extends FSMState<GordoSpikes> {
    
    public GordoStandStill(){
    }
    /**
     * if in Man is not in range stand still
     */
    protected void update() {
        GordoSpikes gordo = getContext();
        if(gordo.inRangeLeft()){
           gotoState(new GordoWalkLeft());
       } else if (gordo.inRangeRight()){
           gotoState(new GordoWalkRight());
       }
    }
    /**
     * Change the x and Y position of Gordo
     */
    protected void enter() {
        GordoSpikes gordo = getContext();
        gordo.setLinearVelocity(new Vec2());
    }

    protected void exit() {}
    
}
