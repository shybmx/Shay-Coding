#include <cstdlib>
#include <iostream>
#include <string>
#include <typeinfo>
#include <map>
#include <list>
using namespace std;

// CPerson class represents a person with firstname and surname
// Did not define any pure virtuals to let users to crete objects for this class
class CPerson
{
protected:
    string m_nameStr;
    string m_surNameStr;
public:
    // Defalut constructor for creating person objects with empty names.
    CPerson()
    {
        m_nameStr="";
        m_surNameStr="";
    }
    // Constructor for creating objects just with FirstName without any surName.
    // Assuming that there will not be a person with just surname
    CPerson(string nameStr)
    {
        m_nameStr=nameStr;
        m_surNameStr="";
    }
    // Constructor for creating  objects with FirstName and SurName.
    CPerson(string nameStr, string surnameStr)
    {
        m_nameStr=nameStr;
        m_surNameStr=surnameStr;
    }
    // Getter for FirstName of Person
    string getName()
    {
        return m_nameStr;
    }
    // Getter for SurName of Person
    string getSurName()
    {
        return m_surNameStr;
    }
    // Setter for FirstName of Person
    void setName(string nameStr)
    {
        m_nameStr= nameStr;
    }
    // Getter for SurName of Person
    void setSurName(string surNameStr)
    {
        m_nameStr=surNameStr;
    }
    
    // The reason for not defining them as pure virtual is because we
    // do not want to make Person as abstract.
    // We would like to allow people to create objects for CPerson class
    
    // Tells whether Person has Telephone
    virtual bool hasTelephone()
    {
        return false;
    }
    // Tells whether Person has Email
    virtual bool hasEmail()
    {
        return false;
    }
    // Getter for Telephonenumber
    virtual string  getTelephoneNumber()
    {
        string s="";
        return s;
    }
    // Setter for Telephonenumber
    virtual string  getEmail()
    {
        string s="";
        return s;
    }
    
    virtual ~CPerson ()
    {
        
    }
    
    // friend function for reading person details
    friend istream & readPerson(istream &, CPerson* &);
    
};

// External functions for <,== and << operators
// Need not be friends because they use getters to access membres
bool operator<(CPerson &,CPerson &);
bool operator==(CPerson &,CPerson &);
ostream & operator<<(ostream &,CPerson &);

// CPersonWithTelephone is derived from CPerson
// with additional memeber to hold phone number
// CPersonWithTelephone is derived virtually from CPerson to avoid dreaded diamond effect
// i.e., to have only one coopy of CPerson in classes derived from CPersonWithTelephone
class CPersonWithTelephone : virtual public CPerson
{
protected:
    string m_phoneNumberStr;
public:
    // Default constructor to empty all members
    CPersonWithTelephone() : CPerson()
    {
        m_phoneNumberStr="";
    }
    // Constructor with name , surname and teplehphone number
    CPersonWithTelephone(string nameStr, string surNameStr, string phoneNumberStr):CPerson(nameStr,surNameStr)
    {
        
        m_phoneNumberStr=phoneNumberStr;
        
    }
    // Constructor with name , without surname and teplehphone number
    CPersonWithTelephone(string nameStr , string phoneNumberStr):CPerson(nameStr)
    {
        m_phoneNumberStr=phoneNumberStr;
        
    }
    // Getter for Telephonenumber
    // should be virtual to allow dynamic binding
    virtual string  getTelephoneNumber()
    {
        return m_phoneNumberStr;
    }
    // Setter for Telephonenumber
    // should be virtual to allow dynamic binding
    virtual void setTelephoneNumber(string phoneNumberStr)
    {
        m_phoneNumberStr=phoneNumberStr;
    }
    // Tells whether person has telephonenumber
    // Assuming a person with empty telephone number is
    // a person without telephone number
    virtual bool hasTelephone()
    {
        if(m_phoneNumberStr.empty()==true)
            return false;
        else
            return true;
    }
    // Friendship is not inherited, so defining readPerson as friend
    friend istream & readPerson(istream &, CPerson* &);
    
};

// CPersonWithEmail is derived from CPerson
// with additional memeber to hold emailid
// CPersonWithEmail is derived virtually from CPerson to avoid dreaded diamond effect
// i.e., to have only one coopy of CPerson in classes derived from CPersonWithTelephone
class CPersonWithEmail : virtual public CPerson
{
protected:
    string m_emailStr;
public:
    // Default constructor to empty all members
    CPersonWithEmail() : CPerson()
    {
        m_emailStr="";
    }
    // Constructor with name , surname and email id
    CPersonWithEmail(string nameStr, string surNameStr, string emailStr):CPerson(nameStr,surNameStr)
    {
        
        m_emailStr=emailStr;
        
    }
    // Constructor with name , without surname and email id
    CPersonWithEmail(string nameStr, string emailStr):CPerson(nameStr)
    {
        
        m_emailStr=emailStr;
        
    }
    // Getter for emailId
    // should be virtual to allow dynamic binding
    virtual  string  getEmail()
    {
        return m_emailStr;
    }
    // Setter for emailId
    // should be virtual to allow dynamic binding
    virtual  void setEmail(string emailStr)
    {
        m_emailStr=emailStr;
    }
    // Checks if a person has email
    // should be virtual to allow dynamic binding
    virtual bool hasEmail()
    {
        if(m_emailStr.empty()==true)
            return false;
        else
            return true;
    }
    // Friendship is not inherited, so defining readPerson as friend
    friend istream & readPerson(istream &, CPerson* &);
    
};

// CPersonWithTelePhoneAndEmail is derived from CPersonWithTelephone and CPersonWithEmail
// Will have only one copy of CPerson
class CPersonWithTelePhoneAndEmail : public  CPersonWithTelephone,public CPersonWithEmail
{
    public :
    //Default constrictor to empty all memebers
    CPersonWithTelePhoneAndEmail():CPerson("","")
    {
        setTelephoneNumber((string)"");
        setEmail((string)"") ;
    }
    // To create objets with name , surname , telephone and email
    CPersonWithTelePhoneAndEmail(string nameStr, string surNameStr, string phoneNumberStr,string emailStr) :
    CPerson( nameStr,surNameStr)
    
    {
        setTelephoneNumber(phoneNumberStr);
        setEmail(emailStr) ;
    }
    // To create objets with name  (without surname) and with telephone and email
    CPersonWithTelePhoneAndEmail(string nameStr, string phoneNumberStr,string emailStr) :
    CPerson( nameStr)
    
    {
        setTelephoneNumber(phoneNumberStr);
        setEmail(emailStr) ;
    }
    
};

// Caller should allocate memory and call this function
// to read and type of person from keyboard
istream & readPerson(istream &i, CPerson* &p)
{
    // Person details are common , so writing without any conditions
    cout<<"Enter Person Details \n";
    cout<<"Enter SurName\n";
    i>>p->m_surNameStr;
    cout<<"Enter Name\n";
    i>>p->m_nameStr;
    
    // identify the type of object to know
    // which details we should be asking user to  input
    // Did not use  typeid.name. Because, it is implementation specific
    if(typeid(*p)==typeid(CPersonWithTelephone) )
    {
        cout<<"Enter TelephoneNumber\n";
        i>> dynamic_cast<CPersonWithTelephone *>(p)->m_phoneNumberStr;
    }
    if(typeid(*p)==typeid(CPersonWithEmail))
    {
        cout<<"Enter EmailID\n";
        i>>dynamic_cast<CPersonWithEmail *>(p)->m_emailStr;
    }
    if(typeid(*p)==typeid(CPersonWithTelePhoneAndEmail))
    {
        cout<<"Enter PhoneNumber\n";
        i>> dynamic_cast<CPersonWithTelePhoneAndEmail *>(p)->m_phoneNumberStr;
        cout<<"Enter Email id\n";
        i>>dynamic_cast<CPersonWithTelePhoneAndEmail *>(p)->m_emailStr;
    }
    return i;
    
}

// To print any type of person object details on screen
ostream & operator<<(ostream &c,CPerson &p)
{
    c<<"<person S "<<p.getSurName()<<" N "<<p.getName();
    
    // use has functions to know what we need to display
    if (p.hasTelephone() && p.hasEmail())
        c<<" T "<<p.getTelephoneNumber()<<" E "<<p.getEmail()<<" >";
    else if (p.hasTelephone())
        c<<" T "<<p.getTelephoneNumber()<<">";
    else if (p.hasEmail())
        c<<" E "<<p.getEmail()<<">";
    else
        c<<">";
    return c;
}

// returns true if lefthand side person's surname occurs
// before right hand side person's name in chronological order
// else returns false
bool operator<(CPerson&  l,CPerson&  r)
{
    
    string a=l.getSurName()+l.getName();
    string b=r.getSurName()+r.getName();
    if(a.compare(b) < 0 )
        return true;
    else
        return false;
    
}

// returns true if lefthand side person's surname and name
// matches with  righthand side person's surname and name
bool operator==(CPerson&  l,CPerson&  r)
{
    if(l.getSurName()== r.getSurName() && l.getName() == r.getName() )
        return true;
    else
        return false;
}

/* CContactList is a class that maps each string (formed by concatenating surname,
 string literal "S" and name ) to a CPerson pointer. */

/* Provides a method that adds any type of CPerson object to
 a CContactList */

/* Used map list because it is more effiecient to search.
 Added "S" literal between SurName and name to avoid following problems
 Because, (Surname = "John"  , FirstName="John" ) and
 (Surname = "Joh"  , FirstName="nJohn") will form the same key "JohnJohn"
 when concatenated and there is a danger to replace the objects with different name.
 If we add a literal "S" string between SurName annd FirstName
 then the keys will become different i.e.,
 (Surname = "John"  , FirstName="John" )  forms a key "JohnSJohn"
 (Surname = "Joh"  , FirstName="John" )  forms a key "JohSJohn".
 
 It also deletes the memory allocated to old object while updating
 person's details */

class CContactList
{
    map< string, CPerson* > m_list;
    
public:
    CContactList()
    {
        
    }
    void add( CPerson* p)
    {
        if(m_list.find( p->getSurName() + (string) "S" + p->getName())  == m_list.end())
            m_list.insert(pair<string, CPerson*>((p->getSurName() + (string)"S" + p->getName()),p));
        else
        {
            delete m_list[p->getSurName() + (string)"S" + p->getName()];
            m_list[p->getSurName() + (string)"S" + p->getName()]=p;
            
        }
        
        
    }
    void display()
    {
        cout<<"\n";
        for( map<string, CPerson * >::const_iterator it = m_list.begin();
            it != m_list.end(); ++it)
        {
            cout<<*(it->second)<<"\n";
            cout<<"\n";
        }
        
    }
    void clear()
    {
        for( map<string, CPerson * >::const_iterator it = m_list.begin();
            it != m_list.end(); ++it)
            delete ((it->second));
        {
        }
    }
    std::list<CPerson> find(string str)
    {
        std::list<CPerson> CList;
        for( map<string, CPerson * >::const_iterator it = m_list.begin();
            it != m_list.end(); ++it)
        {
            if ( (it->second)->getSurName()== str ||  (it->second)->getName()== str )
                CList.push_back(*(it->second));
        }
        
        return CList;
    }
    void withTelephone()
    {
        cout<<"\n";
        for( map<string, CPerson * >::const_iterator it = m_list.begin();
            it != m_list.end() ; ++it)
        {
            if (typeid(*(it->second)) == typeid(CPersonWithTelePhoneAndEmail) ||
                typeid(*(it->second)) == typeid(CPersonWithTelephone) )
            {
                cout<<*(it->second)<<"\n";
                cout<<"\n";
            }
        }
        
    }
    
    
    
};

int main(int argc, char *argv[])
{
    
    char ch;
    CContactList cl;
    while ( true )
    {
        cout<< "=============================\n";
        cout<<"Enter your choice from below \n";
        cout << "1 for entering Person without phone/email \n";
        cout << "2 for entering Person with Phone\n";
        cout << "3 for entering Person with email \n";
        cout << "4 for entering Person with phone & email \n";
        cout << "5 to display the list of contacts \n";
        cout << "6 to search for a person with either a matching name or surname \n";
        cout << "7.to display contacts in order\n";
        cout << "8 to display contacts that have a telephone \n";
        cout << "0 (zero) for exit  \n";
        cout<< "=============================\n";
        cin>>ch;
        cout<<"\n";
        cout<<"\n";
        
        CPerson *p,*pt,*pte,*pe;
        std::list <CPerson> mylist;
        string st;
        switch (ch)
        {
            case '1':
                p= new CPerson();
                readPerson(cin,p);
                cl.add(p);
                cout<<"\n";
                cout<<"\n";
                break;
                
            case '2':
                pt=new CPersonWithTelephone();
                readPerson(cin,pt);
                cl.add(pt);
                cout<<"\n";
                cout<<"\n";
                break;
                
            case '3':
                pe=new CPersonWithEmail();
                readPerson(cin,pe);
                cl.add(pe);
                cout<<"\n";
                cout<<"\n";
                break;
                
            case '4':
                pte=new CPersonWithTelePhoneAndEmail();
                readPerson(cin,pte);
                cl.add(pte);
                cout<<"\n";
                cout<<"\n";
                break;
                
            case '5':
            case '7':
                cout << "List of Contacts \n";
                cl.display();
                cout<<"\n";
                cout<<"\n";
                break;
                
            case '6':
                
                cout<<"enter the name of person you want to search \n";
                cin>>st;
                mylist=cl.find(st);
                
                if(!mylist.empty())
                {
                    cout << "Entries found \n";
                    for (std::list<CPerson>::iterator it=mylist.begin(); it!=mylist.end(); ++it)
                        std::cout << *it<<"\n";
                }
                else
                    cout<<"No such person in contact list";
                cout<<"\n";
                cout<<"\n";
                
                break;
                
            case '8':
                cl.withTelephone();
                cout<<"\n";
                cout<<"\n";
                break;
                
            case '0':
                cl.clear();
                return 0;
                break;
                
        }
        
    }
    
}